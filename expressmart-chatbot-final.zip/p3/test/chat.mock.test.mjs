// Prueba de la función chat.mjs con Gemini SIMULADO (no gasta cuota). Ejecutar: node test/chat.mock.test.mjs
process.env.GEMINI_API_KEY='clave-falsa'; process.env.GEMINI_MODEL='modelo-A'; process.env.GEMINI_FALLBACK='modelo-B';
const mod = await import('../netlify/functions/chat.mjs');
const call = (body, method='POST') => mod.default(new Request('http://x/api/chat',{method, body: method==='POST'?JSON.stringify(body):undefined}));
let ok=0,total=0; const check=(n,c)=>{total++; if(c) ok++; console.log((c?'PASS ':'FAIL ')+n)};
const gem = text => new Response(JSON.stringify({candidates:[{content:{parts:[{text}]}}]}),{status:200});
// 1 éxito con modelo principal
let usados=[]; globalThis.fetch = async (u)=>{usados.push(u.split('models/')[1].split(':')[0]); return gem('hola');};
let r = await call({message:'hola',context:{}}); let j = await r.json();
check('éxito con modelo principal', r.status===200 && j.reply==='hola' && j.model==='modelo-A' && usados.length===1);
// 2 principal 503 -> respaldo
usados=[]; globalThis.fetch = async (u)=>{const m=u.split('models/')[1].split(':')[0]; usados.push(m); return m==='modelo-A'?new Response('busy',{status:503}):gem('desde respaldo');};
r = await call({message:'hola'}); j = await r.json();
check('503 en principal -> usa respaldo', r.status===200 && j.model==='modelo-B' && usados.join()==='modelo-A,modelo-B');
// 3 ambos 429
globalThis.fetch = async ()=> new Response('x',{status:429});
r = await call({message:'hola'}); check('429 en ambos -> 429 amable', r.status===429);
// 4 ambos 503
globalThis.fetch = async ()=> new Response('x',{status:503});
r = await call({message:'hola'}); check('503 en ambos -> 502 con mensaje', r.status===502 && (await r.json()).error.length>5);
// 5 error de red en ambos
globalThis.fetch = async ()=> { throw Object.assign(new Error('net'),{name:'TimeoutError'}); };
r = await call({message:'hola'}); check('timeout en ambos -> 504', r.status===504);
// 6 mensaje vacío, método, sin clave
r = await call({message:'   '}); check('mensaje vacío -> 400', r.status===400);
r = await call(null,'GET'); check('GET -> 405', r.status===405);
// 7 mensaje largo se recorta y la clave no se filtra al cliente
let enviado; globalThis.fetch = async (u,o)=>{enviado=o; return gem('ok');};
r = await call({message:'a'.repeat(2000)}); const txt = await r.text();
check('mensaje recortado a 500', JSON.parse(enviado.body).contents.at(-1).parts[0].text.length===500);
check('la respuesta al cliente no contiene la clave', !txt.includes('clave-falsa'));
check('la clave va en el header, no en la URL', enviado.headers['x-goog-api-key']==='clave-falsa');
// 8 sin clave
delete process.env.GEMINI_API_KEY; r = await call({message:'hola'}); check('sin clave -> 500 claro', r.status===500);
// 9 config
check('config: ruta /api/chat y límite por IP', mod.config.path==='/api/chat' && mod.config.rateLimit.windowLimit===15 && mod.config.rateLimit.aggregateBy.includes('ip'));
console.log(`\nResultado: ${ok}/${total}`);
